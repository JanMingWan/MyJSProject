/*document.writeln("<div style=\"width:252px;margin:10px auto;\"><iframe width=\"250\" height=\"100\" class=\"share_self\"  frameborder=\"0\" scrolling=\"no\"")
document.writeln("src=\"http://widget.weibo.com/weiboshow/index.php?")
document.writeln("language=&width=250&height=100&fansRow=2&ptype=1&speed=0&skin=1&")
document.writeln("isTitle=0&noborder=1&isWeibo=0&isFans=0&uid=3228997053&verifier=e323b3f2&dpc=1\"></iframe></div>")*/
